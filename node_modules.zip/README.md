# CUBE Starter (Vite + React 18 + Tailwind + Framer Motion + lucide-react)

- Стартовый каркас проекта с типографикой: заголовки — Manrope, текст — Jost, базовый — Inter.
- Токены: GOLD `#fbbf24`, фон страницы `#f4f5f7`.
- Блоки по умолчанию: `Header`, `Hero`, `Services`, `About`, `Projects`, `Contact`, `Footer`.

## Запуск
```bash
npm i
npm run dev
```
Откройте `http://localhost:5173`

## Где править
- `src/components/layout/Header.jsx` — шапка (прозрачная до скролла, мобильное меню).
- `src/components/blocks/*` — стандартные секции (пока заглушки).
- `src/index.css` — токены, типографика `.kub-h2` / `.kub-text` и стили кнопок.#   c u b e - s t a r t e r  
 