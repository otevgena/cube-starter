import React from 'react'

export default function Projects(){
  return (
    <section id="projects" className="py-24 bg-page">
      <div className="container-wide">
        <h2 className="kub-h2 text-3xl md:text-4xl">Проекты</h2>
        <p className="kub-text mt-3 text-slate-600">Скоро добавим кейсы.</p>
      </div>
    </section>
  )
}
