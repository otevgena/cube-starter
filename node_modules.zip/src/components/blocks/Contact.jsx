import React from 'react'
export default function Contact(){
  return (
    <section id="contact" className="py-24 bg-white">
      <div className="container-wide">
        <h2 className="kub-h2 text-3xl md:text-4xl">Контакты</h2>
        <p className="kub-text mt-3 text-slate-600">Форма и реквизиты появятся здесь.</p>
      </div>
    </section>
  )
}